package database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import models.Book
import models.History

class DBHelper(context: Context) : SQLiteOpenHelper(context, "Perpustakaan.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE user(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)")
        db.execSQL("CREATE TABLE book(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, isBorrowed INTEGER DEFAULT 0)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, bookId INTEGER, action TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS user")
        db.execSQL("DROP TABLE IF EXISTS book")
        db.execSQL("DROP TABLE IF EXISTS history")
        onCreate(db)
    }

    // Register user
    fun register(username: String, password: String): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
        }
        return db.insert("user", null, values) != -1L
    }

    // Login user
    fun login(username: String, password: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM user WHERE username=? AND password=?", arrayOf(username, password))
        val result = cursor.moveToFirst()
        cursor.close()
        return result
    }

    // Seed initial books if empty
    fun seedBooks() {
        val db = this.writableDatabase
        val cursor = db.rawQuery("SELECT * FROM book", null)
        if (!cursor.moveToFirst()) {
            val books = listOf(
                Book(0, "Laskar Pelangi", "Andrea Hirata", false),
                Book(0, "Bumi Manusia", "Pramoedya Ananta Toer", false),
                Book(0, "Negeri 5 Menara", "Ahmad Fuadi", false)
            )
            for (book in books) {
                val values = ContentValues().apply {
                    put("title", book.title)
                    put("author", book.author)
                    put("isBorrowed", 0)
                }
                db.insert("book", null, values)
            }
        }
        cursor.close()
    }

    // Get all books
    fun getBooks(): List<Book> {
        val books = mutableListOf<Book>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM book", null)
        while (cursor.moveToNext()) {
            books.add(
                Book(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getInt(3) == 1
                )
            )
        }
        cursor.close()
        return books
    }

    // Get book detail by ID
    fun getBookById(id: Int): Book {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM book WHERE id=?", arrayOf(id.toString()))
        return if (cursor.moveToFirst()) {
            val book = Book(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getInt(3) == 1)
            cursor.close()
            book
        } else {
            cursor.close()
            Book(0, "Tidak Diketahui", "Tidak Diketahui", false)
        }
    }

    // Borrow a book
    fun borrowBook(id: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply { put("isBorrowed", 1) }
        val result = db.update("book", values, "id=?", arrayOf(id.toString())) > 0
        if (result) addHistory(id, "Pinjam")
        return result
    }

    // Return a book
    fun returnBook(id: Int): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply { put("isBorrowed", 0) }
        val result = db.update("book", values, "id=?", arrayOf(id.toString())) > 0
        if (result) addHistory(id, "Kembali")
        return result
    }

    // Add history record
    private fun addHistory(bookId: Int, action: String) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("bookId", bookId)
            put("action", action)
        }
        db.insert("history", null, values)
    }

    // Get history list
    fun getHistory(): List<History> {
        val list = mutableListOf<History>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM history ORDER BY timestamp DESC", null)
        while (cursor.moveToNext()) {
            list.add(
                History(
                    cursor.getInt(cursor.getColumnIndexOrThrow("bookId")),
                    cursor.getString(cursor.getColumnIndexOrThrow("action")),
                    cursor.getString(cursor.getColumnIndexOrThrow("timestamp"))
                )
            )
        }
        cursor.close()
        return list
    }
}
