package models

data class History(
    val bookId: Int,
    val action: String,
    val timestamp: String
)
