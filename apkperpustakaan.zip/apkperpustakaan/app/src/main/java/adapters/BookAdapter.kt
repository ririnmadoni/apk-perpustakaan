package adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.apkperpustakaan.R
import database.DBHelper
import models.Book

class BookAdapter(
    private val books: List<Book>,
    private val db: DBHelper,
    private val onActionCompleted: () -> Unit
) : RecyclerView.Adapter<BookAdapter.BookViewHolder>() {

    class BookViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtTitle: TextView = itemView.findViewById(R.id.txtTitle)
        val txtAuthor: TextView = itemView.findViewById(R.id.txtAuthor)
        val btnPinjam: Button = itemView.findViewById(R.id.btnPinjam)
        val btnKembalikan: Button = itemView.findViewById(R.id.btnKembalikan)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_book, parent, false)
        return BookViewHolder(view)
    }

    override fun getItemCount(): Int = books.size

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        val book = books[position]

        holder.txtTitle.text = book.title
        holder.txtAuthor.text = "Penulis: ${book.author}"

        if (book.isBorrowed) {
            holder.btnPinjam.visibility = View.GONE
            holder.btnKembalikan.visibility = View.VISIBLE
        } else {
            holder.btnPinjam.visibility = View.VISIBLE
            holder.btnKembalikan.visibility = View.GONE
        }

        holder.btnPinjam.setOnClickListener {
            val success = db.borrowBook(book.id)
            if (success) {
                Toast.makeText(holder.itemView.context, "Buku dipinjam", Toast.LENGTH_SHORT).show()
                onActionCompleted()
            }
        }

        holder.btnKembalikan.setOnClickListener {
            val success = db.returnBook(book.id)
            if (success) {
                Toast.makeText(holder.itemView.context, "Buku dikembalikan", Toast.LENGTH_SHORT).show()
                onActionCompleted()
            }
        }
    }
}
