package com.example.apkperpustakaan

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import database.DBHelper
import models.History

class HistoryActivity : AppCompatActivity() {

    private lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        db = DBHelper(this)

        val txtHistory = findViewById<TextView>(R.id.txtHistory)
        val historyList: List<History> = db.getHistory()

        val historyText = historyList.joinToString(separator = "\n") { history ->
            "${history.timestamp} - Buku ID ${history.bookId} ${history.action}"
        }

        txtHistory.text = if (historyText.isEmpty()) "Belum ada history" else historyText
    }
}
