package com.example.apkperpustakaan

import adapters.BookAdapter
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import database.DBHelper

class MainActivity : AppCompatActivity() {
    lateinit var db: DBHelper
    lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DBHelper(this)
        db.seedBooks() // tambahkan buku dummy jika belum ada

        recyclerView = findViewById(R.id.recyclerBooks)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val btnHistory = findViewById<Button>(R.id.btnHistory)
        btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        // Load data buku ke RecyclerView
        loadBooks()
    }

    private fun loadBooks() {
        val bookList = db.getBooks()
        recyclerView.adapter = BookAdapter(bookList, db) {
            // Callback saat selesai pinjam atau kembalikan
            loadBooks() // Refresh ulang daftar buku
        }
    }
}
