package com.example.apkperpustakaan

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import database.DBHelper

class BookDetailActivity : AppCompatActivity() {
    private lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book_detail)

        db = DBHelper(this)

        val bookId = intent.getIntExtra("BOOK_ID", 0)
        val book = db.getBookById(bookId)

        val txtTitle = findViewById<TextView>(R.id.txtDetailTitle)
        val txtAuthor = findViewById<TextView>(R.id.txtDetailAuthor)
        val btnReturn = findViewById<Button>(R.id.btnReturn)

        txtTitle.text = book.title
        txtAuthor.text = "by ${book.author}"

        btnReturn.setOnClickListener {
            if (db.returnBook(bookId)) {
                Toast.makeText(this, "Buku berhasil dikembalikan", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Gagal mengembalikan buku", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
